-- name: Dracula
-- version: 1.0
-- description: Dark palette inspired by the Dracula theme, with a light variant.

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x282A36,
        bg_alt            = 0x44475A,

        -- Text
        text              = 0xF8F8F2,
        text_alt          = 0xE6E6E0,
        text_dim          = 0x6272A4,

        -- Bars
        bar_bg            = 0x44475A,

        -- Main Colors
        red               = 0xFF5555,
        green             = 0x50FA7B,
        blue              = 0x8BE9FD,
        orange            = 0xFFB86C,
        purple            = 0xBD93F9,
        cyan              = 0x8BE9FD,
        pink              = 0xFF79C6,
        yellow            = 0xF1FA8C,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x21222C,
        sidebar           = 0x282A36,
        border            = 0x44475A,

        nav_active        = 0x44475A,

        overlay           = 0x191A21,

        module_title      = 0xF8F8F2,
        module_badge      = 0x6272A4,

        position_inactive = 0x6272A4,

        accent            = 0xBD93F9,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xF8F8F2,
        bg_alt            = 0xE6E6E6,

        -- Text
        text              = 0x282A36,
        text_alt          = 0x44475A,
        text_dim          = 0x6272A4,

        -- Bars
        bar_bg            = 0xD6D6D6,

        -- Main Colors
        red               = 0xCC3333,
        green             = 0x229944,
        blue              = 0x168AAD,
        orange            = 0xD97706,
        purple            = 0x7C4DCC,
        cyan              = 0x168AAD,
        pink              = 0xC43C8A,
        yellow            = 0xA67C00,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xFFFFFF,
        sidebar           = 0xF8F8F2,
        border            = 0xD0D0D0,

        nav_active        = 0xE6E6E6,

        overlay           = 0xF0F0F0,

        module_title      = 0x282A36,
        module_badge      = 0x6272A4,

        position_inactive = 0xA0A0A0,

        accent            = 0x7C4DCC,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
