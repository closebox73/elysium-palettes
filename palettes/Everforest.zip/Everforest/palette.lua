-- name: Everforest
-- version: 1.0
-- description: Comfortable green-based color palette inspired by the Everforest theme.

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x2D353B,
        bg_alt            = 0x343F44,

        -- Text
        text              = 0xD3C6AA,
        text_alt          = 0x9DA9A0,
        text_dim          = 0x859289,

        -- Bars
        bar_bg            = 0x3D484D,

        -- Main Colors
        red               = 0xE67E80,
        green             = 0xA7C080,
        blue              = 0x7FBBB3,
        orange            = 0xE69875,
        purple            = 0xD699B6,
        cyan              = 0x83C092,
        pink              = 0xD699B6,
        yellow            = 0xDBBC7F,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x272E33,
        sidebar           = 0x2D353B,
        border            = 0x475258,

        nav_active        = 0x3D484D,

        overlay           = 0x232A2E,

        module_title      = 0xD3C6AA,
        module_badge      = 0x9DA9A0,

        position_inactive = 0x56635F,

        accent            = 0xA7C080,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xFDF6E3,
        bg_alt            = 0xF4F0D9,

        -- Text
        text              = 0x5C6A72,
        text_alt          = 0x829181,
        text_dim          = 0x939F91,

        -- Bars
        bar_bg            = 0xE7E2CC,

        -- Main Colors
        red               = 0xF85552,
        green             = 0x8DA101,
        blue              = 0x3A94C5,
        orange            = 0xF57D26,
        purple            = 0xDF69BA,
        cyan              = 0x35A77C,
        pink              = 0xDF69BA,
        yellow            = 0xDFA000,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xFFF9E8,
        sidebar           = 0xF3EFDA,
        border            = 0xD3C6AA,

        nav_active        = 0xE7E2CC,

        overlay           = 0xF2EFDF,

        module_title      = 0x5C6A72,
        module_badge      = 0x829181,

        position_inactive = 0xA8B0A5,

        accent            = 0x8DA101,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
