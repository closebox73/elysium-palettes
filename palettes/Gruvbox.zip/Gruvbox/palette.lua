-- name: Gruvbox
-- version: 1.0
-- description: Retro groove palette with warm earthy tones and comfortable contrast.

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x282828,
        bg_alt            = 0x3C3836,

        -- Text
        text              = 0xEBDBB2,
        text_alt          = 0xD5C4A1,
        text_dim          = 0xA89984,

        -- Bars
        bar_bg            = 0x504945,

        -- Main Colors
        red               = 0xFB4934,
        green             = 0xB8BB26,
        blue              = 0x83A598,
        orange            = 0xFE8019,
        purple            = 0xD3869B,
        cyan              = 0x8EC07C,
        pink              = 0xD3869B,
        yellow            = 0xFABD2F,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x1D2021,
        sidebar           = 0x282828,
        border            = 0x504945,

        nav_active        = 0x3C3836,

        overlay           = 0x121212,

        position_inactive = 0x504945,

        accent            = 0xFABD2F,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xEBDBB2,
        bg_alt            = 0xD5C4A1,

        -- Text
        text              = 0x3C3836,
        text_alt          = 0x504945,
        text_dim          = 0x7C6F64,

        -- Bars
        bar_bg            = 0xBDAE93,

        -- Main Colors
        red               = 0xCC241D,
        green             = 0x98971A,
        blue              = 0x458588,
        orange            = 0xD65D0E,
        purple            = 0xB16286,
        cyan              = 0x689D6A,
        pink              = 0xB16286,
        yellow            = 0xD79921,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xFBF1C7,
        sidebar           = 0xF2E5BC,
        border            = 0xD5C4A1,

        nav_active        = 0xCDBB96,

        overlay           = 0x000000,

        position_inactive = 0xD5C4A1,

        accent            = 0xD79921,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
