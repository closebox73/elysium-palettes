-- name: Nord
-- version: 1.0
-- description: Arctic-inspired palette based on the Nord color theme.

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x2E3440,
        bg_alt            = 0x3B4252,

        -- Text
        text              = 0xECEFF4,
        text_alt          = 0xE5E9F0,
        text_dim          = 0x81A1C1,

        -- Bars
        bar_bg            = 0x434C5E,

        -- Main Colors
        red               = 0xBF616A,
        green             = 0xA3BE8C,
        blue              = 0x5E81AC,
        orange            = 0xD08770,
        purple            = 0xB48EAD,
        cyan              = 0x88C0D0,
        pink              = 0xD8A9C8,
        yellow            = 0xEBCB8B,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x242933,
        sidebar           = 0x2E3440,
        border            = 0x434C5E,

        nav_active        = 0x434C5E,

        overlay           = 0x1E222A,

        module_title      = 0xECEFF4,
        module_badge      = 0xD8DEE9,

        position_inactive = 0x4C566A,

        accent            = 0x88C0D0,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xECEFF4,
        bg_alt            = 0xE5E9F0,

        -- Text
        text              = 0x2E3440,
        text_alt          = 0x3B4252,
        text_dim          = 0x5E81AC,

        -- Bars
        bar_bg            = 0xD8DEE9,

        -- Main Colors
        red               = 0xBF616A,
        green             = 0xA3BE8C,
        blue              = 0x5E81AC,
        orange            = 0xD08770,
        purple            = 0xB48EAD,
        cyan              = 0x88C0D0,
        pink              = 0xD8A9C8,
        yellow            = 0xEBCB8B,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xFFFFFF,
        sidebar           = 0xECEFF4,
        border            = 0xD8DEE9,

        nav_active        = 0xD8DEE9,

        overlay           = 0x000000,

        module_title      = 0x2E3440,
        module_badge      = 0x4C566A,

        position_inactive = 0xC8D0DC,

        accent            = 0x5E81AC,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
