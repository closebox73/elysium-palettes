-- name: Solarized
-- version: 1.0
-- description: Ethan Schoonover's Solarized palette adapted for Elysium (dark + light).

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x002B36,
        bg_alt            = 0x073642,

        -- Text
        text              = 0xEEE8D5,
        text_alt          = 0x93A1A1,
        text_dim          = 0x657B83,

        -- Bars
        bar_bg            = 0x073642,

        -- Main Colors
        red               = 0xDC322F,
        green             = 0x859900,
        blue              = 0x268BD2,
        orange            = 0xCB4B16,
        purple            = 0x6C71C4,
        cyan              = 0x2AA198,
        pink              = 0xD33682,
        yellow            = 0xB58900,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x002B36,
        sidebar           = 0x073642,
        border            = 0x0F4C5C,

        nav_active        = 0x094352,

        overlay           = 0x001F27,

        module_title      = 0xEEE8D5,
        module_badge      = 0x93A1A1,

        position_inactive = 0x0F4C5C,

        accent            = 0x268BD2,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xFDF6E3,
        bg_alt            = 0xEEE8D5,

        -- Text
        text              = 0x073642,
        text_alt          = 0x586E75,
        text_dim          = 0x93A1A1,

        -- Bars
        bar_bg            = 0xE4DDC7,

        -- Main Colors
        red               = 0xDC322F,
        green             = 0x859900,
        blue              = 0x268BD2,
        orange            = 0xCB4B16,
        purple            = 0x6C71C4,
        cyan              = 0x2AA198,
        pink              = 0xD33682,
        yellow            = 0xB58900,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xFDF6E3,
        sidebar           = 0xF4ECD8,
        border            = 0xD8CFB4,

        nav_active        = 0xE8DFC7,

        overlay           = 0x000000,

        module_title      = 0x073642,
        module_badge      = 0x586E75,

        position_inactive = 0xD8CFB4,

        accent            = 0x268BD2,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
