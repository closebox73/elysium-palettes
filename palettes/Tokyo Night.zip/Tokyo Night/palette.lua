-- name: Tokyo Night
-- version: 1.0
-- description: A clean dark and light color palette inspired by the Tokyo Night theme.

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x1A1B26,
        bg_alt            = 0x24283B,

        -- Text
        text              = 0xC0CAF5,
        text_alt          = 0xA9B1D6,
        text_dim          = 0x565F89,

        -- Bars
        bar_bg            = 0x414868,

        -- Main Colors
        red               = 0xF7768E,
        green             = 0x9ECE6A,
        blue              = 0x7AA2F7,
        orange            = 0xFF9E64,
        purple            = 0xBB9AF7,
        cyan              = 0x7DCFFF,
        pink              = 0xBB9AF7,
        yellow            = 0xE0AF68,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x16161E,
        sidebar           = 0x1A1B26,
        border            = 0x414868,

        nav_active        = 0x292E42,

        overlay           = 0x16161E,

        module_title      = 0xC0CAF5,
        module_badge      = 0xA9B1D6,

        position_inactive = 0x3B4261,

        accent            = 0x7AA2F7,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xE6E7ED,
        bg_alt            = 0xD5D6DB,

        -- Text
        text              = 0x343B58,
        text_alt          = 0x40434F,
        text_dim          = 0x6C6E75,

        -- Bars
        bar_bg            = 0xC8CAD1,

        -- Main Colors
        red               = 0x8C4351,
        green             = 0x385F0D,
        blue              = 0x2959AA,
        orange            = 0x965027,
        purple            = 0x5A3E8E,
        cyan              = 0x0F4B6E,
        pink              = 0x5A3E8E,
        yellow            = 0x8F5E15,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xE1E2E7,
        sidebar           = 0xD5D6DB,
        border            = 0xC4C5CC,

        nav_active        = 0xC9CBD2,

        overlay           = 0xD9DAE0,

        module_title      = 0x343B58,
        module_badge      = 0x40434F,

        position_inactive = 0xB4B6BF,

        accent            = 0x2959AA,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
