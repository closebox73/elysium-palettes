-- name: Elysium
-- version: 2.0
-- description: This is default color palette for Elysium.

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x1b1c1e,
        bg_alt            = 0x232427,

        -- Text
        text              = 0xF9F9F9,
        text_alt          = 0xD0D1D3,
        text_dim          = 0x7E8083,

        -- Bars
        bar_bg            = 0x2A2A2D,

        -- Main Colors
        red               = 0xFF5F56,
        green             = 0x27C93F,
        blue              = 0x007AFF,
        orange            = 0xFF9500,
        purple            = 0x9B59B6,
        cyan              = 0x1ABC9C,
        pink              = 0xFF6EC7,
        yellow            = 0xF1C40F,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x171717,
        sidebar           = 0x202020,
        border            = 0x2B2B2B,

        nav_active        = 0x3A3A3A,

        overlay           = 0x121212,

        module_title      = 0xFFFFFF,
        module_badge      = 0xD0D0D0,

        position_inactive = 0x343434,

        accent            = 0x007AFF,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xF9F9F9,
        bg_alt            = 0xECECEC,

        -- Text
        text              = 0x1B1C1E,
        text_alt          = 0x4A4A4A,
        text_dim          = 0x7E8083,

        -- Bars
        bar_bg            = 0xE0E0E0,

        -- Main Colors
        red               = 0xFF5F56,
        green             = 0x27C93F,
        blue              = 0x007AFF,
        orange            = 0xFF9500,
        purple            = 0x9B59B6,
        cyan              = 0x1ABC9C,
        pink              = 0xFF6EC7,
        yellow            = 0xF1C40F,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xFFFFFF,
        sidebar           = 0xF3F3F3,
        border            = 0xD8D8D8,

        nav_active        = 0xE5E5E5,

        overlay           = 0x000000,

        module_title      = 0x1B1C1E,
        module_badge      = 0x5C5C5C,

        position_inactive = 0xD8D8D8,

        accent            = 0x007AFF,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
