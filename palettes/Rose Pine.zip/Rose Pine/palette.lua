-- name: Rose Pine
-- version: 1.0
-- description: All natural pine, faux fur and a bit of soho vibes for Elysium (dark + light).

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x191724,
        bg_alt            = 0x1F1D2E,

        -- Text
        text              = 0xE0DEF4,
        text_alt          = 0x908CAA,
        text_dim          = 0x6E6A86,

        -- Bars
        bar_bg            = 0x26233A,

        -- Main Colors
        red               = 0xEB6F92,
        green             = 0x31748F,
        blue              = 0x9CCFD8,
        orange            = 0xF6C177,
        purple            = 0xC4A7E7,
        cyan              = 0x9CCFD8,
        pink              = 0xEBBCBA,
        yellow            = 0xF6C177,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x191724,
        sidebar           = 0x1F1D2E,
        border            = 0x312F44,

        nav_active        = 0x26233A,

        overlay           = 0x16141F,

        module_title      = 0xE0DEF4,
        module_badge      = 0x908CAA,

        position_inactive = 0x312F44,

        accent            = 0xC4A7E7,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xFAF4ED,
        bg_alt            = 0xFFF8F0,

        -- Text
        text              = 0x575279,
        text_alt          = 0x797593,
        text_dim          = 0x9893A5,

        -- Bars
        bar_bg            = 0xF2E9E1,

        -- Main Colors
        red               = 0xB4637A,
        green             = 0x286983,
        blue              = 0x56949F,
        orange            = 0xEA9D34,
        purple            = 0x907AA9,
        cyan              = 0x56949F,
        pink              = 0xD7827E,
        yellow            = 0xEA9D34,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xFAF4ED,
        sidebar           = 0xFFF8F0,
        border            = 0xE8DCCF,

        nav_active        = 0xF2E9E1,

        overlay           = 0x000000,

        module_title      = 0x575279,
        module_badge      = 0x797593,

        position_inactive = 0xE8DCCF,

        accent            = 0x907AA9,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
