-- name: Catppuccin
-- version: 1.0
-- description: Soothing pastel palette inspired by the Catppuccin theme.

local palette = {

    dark = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0x1E1E2E,
        bg_alt            = 0x313244,

        -- Text
        text              = 0xCDD6F4,
        text_alt          = 0xBAC2DE,
        text_dim          = 0x7F849C,

        -- Bars
        bar_bg            = 0x45475A,

        -- Main Colors
        red               = 0xF38BA8,
        green             = 0xA6E3A1,
        blue              = 0x89B4FA,
        orange            = 0xFAB387,
        purple            = 0xCBA6F7,
        cyan              = 0x94E2D5,
        pink              = 0xF5C2E7,
        yellow            = 0xF9E2AF,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0x181825,
        sidebar           = 0x1E1E2E,
        border            = 0x45475A,

        nav_active        = 0x45475A,

        overlay           = 0x11111B,

        module_title      = 0xCDD6F4,
        module_badge      = 0xBAC2DE,

        position_inactive = 0x585B70,

        accent            = 0x89B4FA,
    },

    light = {

        -- =====================================================
        -- Widget Colors
        -- =====================================================

        -- Base
        bg                = 0xEFF1F5,
        bg_alt            = 0xE6E9EF,

        -- Text
        text              = 0x4C4F69,
        text_alt          = 0x5C5F77,
        text_dim          = 0x8C8FA1,

        -- Bars
        bar_bg            = 0xDCE0E8,

        -- Main Colors
        red               = 0xD20F39,
        green             = 0x40A02B,
        blue              = 0x1E66F5,
        orange            = 0xFE640B,
        purple            = 0x8839EF,
        cyan              = 0x179299,
        pink              = 0xEA76CB,
        yellow            = 0xDF8E1D,

        -- =====================================================
        -- GUI Colors
        -- =====================================================

        window            = 0xFFFFFF,
        sidebar           = 0xEFF1F5,
        border            = 0xCCD0DA,

        nav_active        = 0xDCE0E8,

        overlay           = 0x000000,

        module_title      = 0x4C4F69,
        module_badge      = 0x6C6F85,

        position_inactive = 0xBCC0CC,

        accent            = 0x1E66F5,
    }
}

local mode = "dark"

function palette.set_mode(new_mode)
    if new_mode == "light" then
        mode = "light"
    else
        mode = "dark"
    end
end

function palette.get(name, fallback)
    return palette[mode][name]
        or fallback
        or palette[mode].text
end

return palette
